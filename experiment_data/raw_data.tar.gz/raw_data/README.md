abc_pdr     -> pdr
abc_dprove  -> dprove
abc_pdr-nct -> pdr-nct
nuXmv_ic3ia -> nuxmv-ic3ia
avr_sa      -> avr-ic3sa
avr_Y2      -> avr-ic3sa-uf
